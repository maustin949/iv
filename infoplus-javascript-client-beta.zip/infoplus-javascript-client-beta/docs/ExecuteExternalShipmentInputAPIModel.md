# infoplus.ExecuteExternalShipmentInputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idList** | **[Number]** |  | [optional] 


