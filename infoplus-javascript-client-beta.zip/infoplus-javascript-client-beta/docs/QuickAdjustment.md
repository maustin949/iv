# infoplus.QuickAdjustment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | 
**locationId** | **Number** |  | 
**lobId** | **Number** |  | [optional] 
**adjustmentCode** | **String** |  | 
**totalQuantity** | **Number** |  | [optional] 
**changeQuantity** | **Number** |  | [optional] 
**message** | **String** |  | [optional] 
**status** | **String** |  | [optional] 
**productIdTag** | **String** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 
**sku** | **String** |  | [optional] 


