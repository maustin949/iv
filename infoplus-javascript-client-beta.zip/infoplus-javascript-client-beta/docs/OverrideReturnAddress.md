# infoplus.OverrideReturnAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**lobId** | **Number** |  | 
**warehouseId** | **Number** |  | 
**orderSourceId** | **Number** |  | 
**name** | **String** |  | 
**attention** | **String** |  | [optional] 
**street** | **String** |  | 
**street2** | **String** |  | [optional] 
**street3Province** | **String** |  | [optional] 
**city** | **String** |  | 
**state** | **String** |  | [optional] 
**zip** | **String** |  | 
**country** | **String** |  | 
**phone** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


