# infoplus.OrderWarehouseFulfillmentPlanDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warehouseId** | **Number** |  | [optional] 
**carrierCode** | **Number** |  | [optional] 
**lineItemList** | **[String]** |  | [optional] 


