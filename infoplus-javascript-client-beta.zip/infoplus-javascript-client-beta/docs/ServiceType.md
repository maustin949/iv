# infoplus.ServiceType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceType** | **String** |  | 
**label** | **String** |  | 


