# infoplus.JobTime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**secondDuration** | **Number** |  | 
**_date** | **Date** |  | [optional] 
**userId** | **Number** |  | 
**lobId** | **Number** |  | 
**jobTypeId** | **Number** |  | 
**note** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


