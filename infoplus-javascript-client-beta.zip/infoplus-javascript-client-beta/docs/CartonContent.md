# infoplus.CartonContent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**groupOrderId** | **Number** |  | [optional] 
**orderNo** | **Number** |  | 
**cartonNo** | **Number** |  | [optional] 
**cartonId** | **Number** |  | 
**lineItemId** | **Number** |  | 
**sku** | **String** |  | [optional] 
**location** | **String** |  | [optional] 
**quantity** | **Number** |  | 
**quantityScanned** | **Number** |  | [optional] 
**completed** | **Date** |  | [optional] 
**toteId** | **String** |  | [optional] 
**pickerId** | **String** |  | [optional] 
**status** | **String** |  | [optional] 
**lobId** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


