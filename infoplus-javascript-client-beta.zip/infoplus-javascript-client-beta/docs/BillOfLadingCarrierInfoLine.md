# infoplus.BillOfLadingCarrierInfoLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**seqNo** | **Number** |  | [optional] 
**huQuantity** | **Number** |  | [optional] 
**huType** | **String** |  | [optional] 
**packageQuantity** | **Number** |  | [optional] 
**packageType** | **String** |  | [optional] 
**weight** | **Number** |  | [optional] 
**isHazardousMaterial** | **Boolean** |  | [optional] [default to false]
**commodityDescription** | **String** |  | 
**nfmcNo** | **String** |  | [optional] 
**carrierClass** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


