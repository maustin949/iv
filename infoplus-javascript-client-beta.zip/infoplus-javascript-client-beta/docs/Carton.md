# infoplus.Carton

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**orderNo** | **Number** |  | 
**cartonNo** | **Number** |  | 
**cartonTypeId** | **Number** |  | 
**cartonLPN** | **String** |  | [optional] 
**weightLbs** | **Number** |  | [optional] 
**layoutPosition** | **String** |  | [optional] 
**lobId** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


