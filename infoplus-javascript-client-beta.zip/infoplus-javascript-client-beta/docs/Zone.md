# infoplus.Zone

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | 
**name** | **String** |  | 
**address** | **String** |  | [optional] 
**isClimateControlled** | **Boolean** |  | [optional] [default to false]
**isFoodGrade** | **Boolean** |  | [optional] [default to false]
**isSecure** | **Boolean** |  | [optional] [default to false]
**isFrozen** | **Boolean** |  | [optional] [default to false]
**isRefrigerated** | **Boolean** |  | [optional] [default to false]
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


