# infoplus.BusinessTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**serverName** | **String** |  | [optional] 
**queueName** | **String** |  | [optional] 
**lobId** | **Number** |  | 
**messageBody** | **String** |  | [optional] 
**alertId** | **Number** |  | [optional] 
**status** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


