# infoplus.FulfillmentLayoutPosition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**fulfillmentProcessId** | **Number** |  | [optional] 
**lobId** | **Number** |  | [optional] 
**pickPosition** | **String** |  | [optional] 
**layoutPosition** | **String** |  | [optional] 
**sku** | **String** |  | [optional] 
**quantity** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


