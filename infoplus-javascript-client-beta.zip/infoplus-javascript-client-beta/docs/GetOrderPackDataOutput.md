# infoplus.GetOrderPackDataOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderNo** | **String** |  | [optional] 
**order** | [**Order**](Order.md) |  | [optional] 
**palletList** | [**[PackedPallet]**](PackedPallet.md) |  | [optional] 
**masterCartonList** | [**[PackedMasterCarton]**](PackedMasterCarton.md) |  | [optional] 
**cartonList** | [**[PackedCarton]**](PackedCarton.md) |  | [optional] 
**fullItemList** | [**[PackedItem]**](PackedItem.md) |  | [optional] 
**unpackedItemList** | [**[PackedItem]**](PackedItem.md) |  | [optional] 


