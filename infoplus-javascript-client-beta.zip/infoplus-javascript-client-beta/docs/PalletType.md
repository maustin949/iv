# infoplus.PalletType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | 
**palletLengthIn** | **Number** |  | 
**palletWidthIn** | **Number** |  | 
**palletHeightIn** | **Number** |  | 
**palletWeightLbs** | **Number** |  | [optional] 
**packableLengthIn** | **Number** |  | 
**packableWidthIn** | **Number** |  | 
**packableHeightIn** | **Number** |  | 
**lobId** | **Number** |  | 
**isActive** | **Boolean** |  | [default to false]
**customFields** | **{String: Object}** |  | [optional] 


