# infoplus.Work

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**sourceWarehouseId** | **Number** |  | 
**sourceBuildingId** | **Number** |  | 
**sourceLocation** | **String** |  | 
**destinationWarehouseId** | **Number** |  | 
**destinationBuildingId** | **Number** |  | 
**destinationLocation** | **String** |  | 
**type** | **String** |  | 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**priorityCode** | **Number** |  | 
**userDefinedMessage** | **String** |  | [optional] 
**status** | **String** |  | 
**userId** | **Number** |  | 
**lobId** | **Number** |  | [optional] 
**workBatchId** | **Number** |  | [optional] 
**workProductList** | [**[WorkProduct]**](WorkProduct.md) |  | [optional] 
**fulfillmentProcessId** | **Number** |  | [optional] 
**pickLineId** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


