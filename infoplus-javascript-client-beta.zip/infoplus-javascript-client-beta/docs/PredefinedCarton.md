# infoplus.PredefinedCarton

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**label** | **String** |  | 


