# infoplus.PackedCarton

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


