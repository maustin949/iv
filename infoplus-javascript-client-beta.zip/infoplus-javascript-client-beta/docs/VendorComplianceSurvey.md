# infoplus.VendorComplianceSurvey

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**worksheetId** | **Number** |  | 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**surveyQuestions** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


