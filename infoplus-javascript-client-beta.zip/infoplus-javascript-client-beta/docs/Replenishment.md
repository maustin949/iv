# infoplus.Replenishment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**replenishmentProcess** | **Number** |  | [optional] 
**pickFaceAssignment** | **Number** |  | [optional] 
**locationId** | **Number** |  | 
**quantity** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 
**sku** | **String** |  | [optional] 


