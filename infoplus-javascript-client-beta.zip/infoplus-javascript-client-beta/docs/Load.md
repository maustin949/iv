# infoplus.Load

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**lobId** | **Number** |  | [optional] 
**lpn** | **String** |  | 
**behaviorType** | **String** |  | 
**warehouseId** | **Number** |  | 
**locationId** | **Number** |  | [optional] 
**parentLoadId** | **Number** |  | [optional] 
**palletTypeId** | **Number** |  | [optional] 
**cartonTypeId** | **Number** |  | [optional] 
**orderNoList** | **[Number]** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


