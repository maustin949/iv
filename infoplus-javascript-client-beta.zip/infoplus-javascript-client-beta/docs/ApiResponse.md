# infoplus.ApiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


