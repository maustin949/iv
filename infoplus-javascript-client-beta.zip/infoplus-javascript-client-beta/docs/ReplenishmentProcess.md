# infoplus.ReplenishmentProcess

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**warehouseId** | **Number** |  | 
**replenishmentPlanId** | **Number** |  | 
**status** | **String** |  | 
**estimatedWork** | **Number** |  | [optional] 
**workBatchId** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


