# infoplus.OrderWarehouseFulfillmentRawSkuData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **Number** |  | [optional] 
**canFulfill** | **Boolean** |  | [optional] [default to false]


