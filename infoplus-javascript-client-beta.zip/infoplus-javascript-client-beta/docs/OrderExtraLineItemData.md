# infoplus.OrderExtraLineItemData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sku** | **String** |  | [optional] 
**category** | **String** |  | [optional] 
**code** | **String** |  | [optional] 
**value** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


