# infoplus.InvoiceWorksheetLineDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**lobId** | **Number** |  | 
**quantity** | **Number** |  | [optional] 
**chargeRate** | **Number** |  | [optional] 
**extendedCharge** | **Number** |  | [optional] 
**invoiceWorksheetId** | **Number** |  | 
**invoiceWorksheetLineId** | **Number** |  | [optional] 
**activityType** | **String** |  | [optional] 
**activityRecordID** | **String** |  | [optional] 
**reference1** | **String** |  | [optional] 
**reference2** | **String** |  | [optional] 
**reference3** | **String** |  | [optional] 
**reference4** | **String** |  | [optional] 
**reference5** | **String** |  | [optional] 
**activityRecord** | **{String: Object}** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


