# infoplus.PickFaceAssignment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | 
**locationId** | **Number** |  | 
**replenishmentPoint** | **Number** |  | 
**maxQuantity** | **Number** |  | 
**active** | **Boolean** |  | [default to false]
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 
**sku** | **String** |  | [optional] 


