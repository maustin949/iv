# infoplus.ParcelAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**carrierCompany** | **String** |  | 
**accountNo** | **String** |  | 
**lobId** | **Number** |  | [optional] 
**orderSourceId** | **Number** |  | [optional] 
**client** | **Number** |  | [optional] 
**ipcDatabaseId** | **Number** |  | [optional] 
**name** | **String** |  | 
**manifestPartner** | **Number** |  | [optional] 
**manifestPartnerId** | **String** |  | 
**manifestPartnerCredentials** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


