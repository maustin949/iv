# infoplus.BillingCode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**quantity** | **Number** |  | 
**_date** | **Date** |  | 
**userId** | **Number** |  | 
**lobId** | **Number** |  | [optional] 
**billingCodeTypeId** | **Number** |  | 
**recordType** | **String** |  | [optional] 
**recordId** | **String** |  | [optional] 
**note** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


