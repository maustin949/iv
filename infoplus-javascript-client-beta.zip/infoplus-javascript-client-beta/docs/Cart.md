# infoplus.Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**cartId** | **String** |  | 
**description** | **String** |  | [optional] 
**currentFulfillmentProcessId** | **Number** |  | [optional] 
**currentWorkBatchId** | **Number** |  | [optional] 
**positionType** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


