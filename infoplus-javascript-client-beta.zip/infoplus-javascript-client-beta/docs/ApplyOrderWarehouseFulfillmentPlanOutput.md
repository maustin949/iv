# infoplus.ApplyOrderWarehouseFulfillmentPlanOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderList** | [**[Order]**](Order.md) |  | [optional] 


