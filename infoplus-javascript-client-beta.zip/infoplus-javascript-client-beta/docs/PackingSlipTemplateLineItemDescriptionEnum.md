# infoplus.PackingSlipTemplateLineItemDescriptionEnum

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**label** | **String** |  | 


