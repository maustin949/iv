# infoplus.ExecuteQuickAdjustmentInputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idList** | **[Number]** |  | [optional] 


