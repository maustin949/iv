# infoplus.ExecuteQuickReceiptInputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idList** | **[Number]** |  | [optional] 


