# infoplus.OrderSourceReservation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**orderSourceId** | **Number** |  | 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**reservedQuantity** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 
**sku** | **String** |  | [optional] 


