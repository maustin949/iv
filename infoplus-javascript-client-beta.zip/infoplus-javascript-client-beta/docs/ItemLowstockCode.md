# infoplus.ItemLowstockCode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lobId** | **Number** |  | 
**internalId** | **Number** |  | [optional] 
**id** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


