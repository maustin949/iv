# infoplus.BillingCodeActivity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**importedId** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**_date** | **Date** |  | [optional] 
**quantity** | **Number** |  | 
**lobId** | **Number** |  | 
**userId** | **Number** |  | 
**email** | **String** |  | [optional] 
**billingCodeTypeId** | **Number** |  | 
**billingCodeTypeName** | **String** |  | 
**note** | **String** |  | [optional] 
**recordTypeName** | **String** |  | [optional] 
**recordTypeId** | **Number** |  | [optional] 
**recordId** | **String** |  | [optional] 
**billingQuantity** | **Number** |  | [optional] 
**chargeRate** | **Number** |  | [optional] 
**extendedCharge** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


