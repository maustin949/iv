# infoplus.ManifestPartner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**label** | **String** |  | 


