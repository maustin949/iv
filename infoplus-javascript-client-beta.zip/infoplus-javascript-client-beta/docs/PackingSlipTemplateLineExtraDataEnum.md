# infoplus.PackingSlipTemplateLineExtraDataEnum

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**label** | **String** |  | 


