# infoplus.OverrideReceiptsForFulfillment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemReceiptId** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


