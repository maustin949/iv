# infoplus.Alert

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**type** | **String** |  | 
**level** | **String** |  | 
**message** | **String** |  | 
**link** | **String** |  | [optional] 
**linkText** | **String** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**expirationDate** | **Date** |  | [optional] 
**acknowledgeDate** | **Date** |  | [optional] 
**lobId** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


