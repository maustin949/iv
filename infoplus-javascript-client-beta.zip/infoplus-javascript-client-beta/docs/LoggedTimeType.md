# infoplus.LoggedTimeType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**label** | **String** |  | 


