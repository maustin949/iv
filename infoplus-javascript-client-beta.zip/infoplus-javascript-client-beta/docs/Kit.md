# infoplus.Kit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lobId** | **Number** |  | 
**id** | **Number** |  | [optional] 
**kitSKU** | **String** |  | 
**packagingType** | **String** |  | [optional] 
**other** | **String** |  | [optional] 
**numberOfComponents** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**line1** | **String** |  | [optional] 
**line2** | **String** |  | [optional] 
**line3** | **String** |  | [optional] 
**line4** | **String** |  | [optional] 
**line5** | **String** |  | [optional] 
**line6** | **String** |  | [optional] 
**line7** | **String** |  | [optional] 
**line8** | **String** |  | [optional] 
**touches** | **Number** |  | 
**minInvQty** | **Number** |  | [optional] 
**midInvQty** | **Number** |  | [optional] 
**maxInvQty** | **Number** |  | [optional] 
**isKOD** | **String** |  | 
**kodType** | **String** |  | [optional] 
**kitComponentList** | [**[KitComponent]**](KitComponent.md) |  | 
**customFields** | **{String: Object}** |  | [optional] 


