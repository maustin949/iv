# infoplus.OrderWarehouseFulfillmentPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**score** | **Number** |  | [optional] 
**planDetailList** | [**[OrderWarehouseFulfillmentPlanDetail]**](OrderWarehouseFulfillmentPlanDetail.md) |  | 


