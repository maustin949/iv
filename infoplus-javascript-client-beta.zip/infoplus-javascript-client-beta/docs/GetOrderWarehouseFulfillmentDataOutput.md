# infoplus.GetOrderWarehouseFulfillmentDataOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rawData** | [**{String: OrderWarehouseFulfillmentRawData}**](OrderWarehouseFulfillmentRawData.md) |  | 
**planList** | [**[OrderWarehouseFulfillmentPlan]**](OrderWarehouseFulfillmentPlan.md) |  | 


