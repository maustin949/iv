# infoplus.LowStock

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | 
**lowLevelDate** | **Date** |  | [optional] 
**lowStockMessage** | **String** |  | [optional] 
**printFlag** | **String** |  | [optional] 
**isDelayed** | **Boolean** |  | [optional] [default to false]
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 
**sku** | **String** |  | [optional] 


