# infoplus.Carrier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**carrier** | **Number** |  | 
**label** | **String** |  | 
**scac** | **String** |  | 


