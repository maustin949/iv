# infoplus.GS1128LabelDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**gs1128TemplateId** | **Number** |  | [optional] 
**noOfCopies** | **Number** |  | [optional] 
**lobId** | **Number** |  | 
**orderNo** | **Number** |  | 
**recordType** | **String** |  | [optional] 
**palletLoadId** | **Number** |  | [optional] 
**masterCartonLoadId** | **Number** |  | [optional] 
**cartonId** | **Number** |  | [optional] 
**lineItemId** | **Number** |  | [optional] 
**lineItemUnitNo** | **Number** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**sscc** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


