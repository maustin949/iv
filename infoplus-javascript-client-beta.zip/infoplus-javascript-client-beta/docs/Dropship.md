# infoplus.Dropship

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**orderId** | **Number** |  | 
**sku** | **String** |  | 
**quantity** | **Number** |  | [optional] 
**orderDate** | **Date** |  | [optional] 
**vendor** | **Number** |  | 
**lobId** | **Number** |  | 
**transmitDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


