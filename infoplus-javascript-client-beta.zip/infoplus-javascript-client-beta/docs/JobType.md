# infoplus.JobType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**clientId** | **Number** |  | 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**name** | **String** |  | 
**description** | **String** |  | [optional] 
**jobCode** | **String** |  | 
**isActive** | **Boolean** |  | [optional] [default to false]
**customFields** | **{String: Object}** |  | [optional] 


