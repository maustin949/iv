# infoplus.ReceivingProcess

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | 
**status** | **String** |  | 
**workBatchId** | **Number** |  | [optional] 
**receivingWorksheetId** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


