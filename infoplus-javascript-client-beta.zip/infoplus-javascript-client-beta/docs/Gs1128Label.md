# infoplus.Gs1128Label

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**sscc** | **String** |  | [optional] 
**lobId** | **Number** |  | 
**orderNo** | **Number** |  | 
**gs1128TemplateId** | **Number** |  | 
**noOfCopies** | **Number** |  | [optional] 
**recordType** | **String** |  | [optional] 
**palletLoadId** | **Number** |  | [optional] 
**masterCartonLoadId** | **Number** |  | [optional] 
**cartonId** | **Number** |  | [optional] 
**lineItemId** | **Number** |  | [optional] 
**lineItemUnitNo** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


