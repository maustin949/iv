# infoplus.RunFulfillmentPlanInputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderNoList** | **[Number]** |  | [optional] 
**fulfillmentPlanId** | **Number** |  | 
**maxSKUsPerBatch** | **Number** |  | [optional] 
**firstPickPosition** | **Number** |  | [optional] 
**maxCartons** | **Number** |  | [optional] 
**shipDate** | **Date** |  | 


