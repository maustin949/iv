# infoplus.InvoiceWorksheetLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**lobId** | **Number** |  | 
**seqNo** | **Number** |  | [optional] 
**description** | **String** |  | [optional] 
**accountCode** | **String** |  | [optional] 
**department** | **String** |  | [optional] 
**itemCode** | **String** |  | [optional] 
**quantity** | **Number** |  | [optional] 
**chargeRate** | **Number** |  | [optional] 
**extendedCharge** | **Number** |  | [optional] 
**backupFile** | **Number** |  | [optional] 
**backupDocument** | **String** |  | [optional] 
**invoiceWorksheetId** | **Number** |  | 
**invoiceTemplateLineId** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


