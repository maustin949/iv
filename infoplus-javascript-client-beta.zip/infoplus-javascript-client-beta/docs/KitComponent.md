# infoplus.KitComponent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sku** | **String** |  | 
**quantity** | **Number** |  | 
**instructions** | **String** |  | [optional] 
**additionalServices** | **String** |  | [optional] 
**critical** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


