# infoplus.JobRecipeStep

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sequenceNo** | **Number** |  | [optional] 
**name** | **String** |  | 
**assemblyInstructions** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


