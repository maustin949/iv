# infoplus.ParcelInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**carrier** | **String** |  | [optional] 
**invoiceNo** | **String** |  | [optional] 
**accountNo** | **String** |  | [optional] 
**invoiceDate** | **Date** |  | [optional] 
**invoiceAmount** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


