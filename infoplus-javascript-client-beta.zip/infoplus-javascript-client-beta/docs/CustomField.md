# infoplus.CustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**name** | **String** |  | 
**label** | **String** |  | 
**enabled** | **Boolean** |  | [default to false]
**fieldType** | **String** |  | 
**searchable** | **Boolean** |  | [default to false]
**tooltip** | **String** |  | [optional] 
**tabLabel** | **String** |  | 
**recordType** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


