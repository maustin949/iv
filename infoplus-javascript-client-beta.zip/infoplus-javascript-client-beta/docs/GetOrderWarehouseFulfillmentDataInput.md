# infoplus.GetOrderWarehouseFulfillmentDataInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderNo** | **String** |  | 


