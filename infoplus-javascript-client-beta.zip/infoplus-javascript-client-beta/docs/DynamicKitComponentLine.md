# infoplus.DynamicKitComponentLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lobId** | **Number** |  | 
**sku** | **String** |  | 
**perKitQuantity** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


