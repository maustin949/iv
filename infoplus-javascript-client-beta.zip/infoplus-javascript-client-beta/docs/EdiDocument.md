# infoplus.EdiDocument

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**ediConnectionId** | **Number** |  | 
**as2PartnerId** | **Number** |  | 
**lobId** | **Number** |  | [optional] 
**transactionType** | **String** |  | 
**direction** | **String** |  | 
**documentTypeId** | **Number** |  | 
**status** | **String** |  | 
**interchangeIndex** | **Number** |  | [optional] 
**groupIndex** | **Number** |  | [optional] 
**transactionIndex** | **Number** |  | [optional] 
**body** | **String** |  | 
**jsonBody** | **String** |  | 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


