# infoplus.Substitution

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lobId** | **Number** |  | 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**id** | **Number** |  | [optional] 
**orderSKU** | **String** |  | 
**substituteSKU** | **String** |  | 
**period** | **String** |  | 
**type** | **String** |  | 
**substitutionQuantity** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


