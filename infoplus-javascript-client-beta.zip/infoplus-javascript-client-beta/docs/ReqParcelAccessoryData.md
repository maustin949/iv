# infoplus.ReqParcelAccessoryData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessory** | **String** |  | 
**amount** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


