# infoplus.PackedPallet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


