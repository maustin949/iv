# infoplus.JobTimeActivity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**importedId** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**_date** | **Date** |  | [optional] 
**secondDuration** | **Number** |  | 
**userId** | **Number** |  | 
**email** | **String** |  | [optional] 
**lobId** | **Number** |  | 
**jobTypeId** | **Number** |  | 
**jobTypeName** | **String** |  | [optional] 
**note** | **String** |  | [optional] 
**billingQuantity** | **Number** |  | [optional] 
**chargeRate** | **Number** |  | [optional] 
**extendedCharge** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


