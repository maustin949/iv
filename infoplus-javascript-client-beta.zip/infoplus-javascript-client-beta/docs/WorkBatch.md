# infoplus.WorkBatch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | 
**batchPriorityCode** | **Number** |  | [optional] 
**description** | **String** |  | [optional] 
**assignedUserId** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


