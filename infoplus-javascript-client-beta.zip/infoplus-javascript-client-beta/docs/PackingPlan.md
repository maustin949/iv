# infoplus.PackingPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**fulfillmentProcessId** | **Number** |  | 
**status** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


