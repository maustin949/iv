# infoplus.OrderExtraOrderData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sequence** | **String** |  | [optional] 
**category** | **String** |  | [optional] 
**code** | **String** |  | [optional] 
**value** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


