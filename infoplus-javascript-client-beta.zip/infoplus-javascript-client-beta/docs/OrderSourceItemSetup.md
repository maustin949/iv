# infoplus.OrderSourceItemSetup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**lobId** | **Number** |  | 
**sku** | **String** |  | 
**orderSourceId** | **Number** |  | 
**packingNotes** | **String** |  | [optional] 
**skuTranslation** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


