# infoplus.ExecuteJobInputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idList** | **[Number]** |  | [optional] 


