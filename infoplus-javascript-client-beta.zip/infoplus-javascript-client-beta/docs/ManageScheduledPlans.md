# infoplus.ManageScheduledPlans

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**description** | **String** |  | [optional] 
**scheduledplantypeid** | **Number** |  | [optional] 
**planid** | **Number** |  | [optional] 
**active** | **Boolean** |  | [optional] [default to false]
**user** | **Number** |  | [optional] 
**deleted** | **Boolean** |  | [optional] [default to false]
**warehouseId** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


