# infoplus.InvoiceTemplateLinePriceLevel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**quantity** | **Number** |  | [optional] 
**rate** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


