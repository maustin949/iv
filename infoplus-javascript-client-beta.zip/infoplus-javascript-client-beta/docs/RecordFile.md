# infoplus.RecordFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**fileName** | **String** |  | [optional] 
**extension** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**roleName** | **String** |  | [optional] 
**label** | **String** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**printerTypeId** | **Number** |  | [optional] 
**userFullName** | **String** |  | [optional] 


