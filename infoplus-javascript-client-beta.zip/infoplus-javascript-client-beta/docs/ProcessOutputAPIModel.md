# infoplus.ProcessOutputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Object** |  | [optional] 
**status** | **String** |  | [optional] 
**entity** | **Object** |  | [optional] 
**messageList** | **[String]** |  | [optional] 


