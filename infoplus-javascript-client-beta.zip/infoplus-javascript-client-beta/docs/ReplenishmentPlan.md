# infoplus.ReplenishmentPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**warehouseId** | **Number** |  | 
**pickFaceAssignmentSmartFilterId** | **Number** |  | 
**name** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


