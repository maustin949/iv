# infoplus.JobRecipeInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sku** | **String** |  | 
**quantity** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


