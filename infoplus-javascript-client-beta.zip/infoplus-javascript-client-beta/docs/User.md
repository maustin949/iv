# infoplus.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **Number** |  | 
**label** | **String** |  | 


