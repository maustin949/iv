# infoplus.GetOrderPackDataInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderNo** | **String** |  | 


