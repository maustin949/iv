# infoplus.EditLineItemFulfillmentStrategyInputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderNoList** | **[Number]** |  | [optional] 
**fulfillmentChannelId** | **Number** |  | 
**sku** | **String** |  | [optional] 


