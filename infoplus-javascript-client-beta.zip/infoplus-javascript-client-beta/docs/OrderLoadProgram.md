# infoplus.OrderLoadProgram

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**label** | **String** |  | 


