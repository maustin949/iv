# infoplus.FinanceSystemConnectionLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**financeSystemConnectionId** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 
**notes** | **String** |  | [optional] 
**orderNo** | **Number** |  | [optional] 
**financeSystemOrderNo** | **String** |  | [optional] 
**financeSystemOrderId** | **String** |  | [optional] 
**asnId** | **Number** |  | [optional] 
**financeSystemPONo** | **String** |  | [optional] 
**financeSystemPOId** | **String** |  | [optional] 
**itemReceiptIdId** | **Number** |  | [optional] 
**adjustmentIdId** | **Number** |  | [optional] 
**jobIdId** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


