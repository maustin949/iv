# infoplus.OrderWarehouseFulfillmentRawData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warehouseId** | **Number** |  | [optional] 
**canFulfill** | **Boolean** |  | [optional] [default to false]
**skuMap** | [**{String: OrderWarehouseFulfillmentRawSkuData}**](OrderWarehouseFulfillmentRawSkuData.md) |  | [optional] 


