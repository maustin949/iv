# infoplus.ScheduledPlanLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**scheduledPlanId** | **Number** |  | [optional] 
**plan** | **String** |  | [optional] 
**startTime** | **Date** |  | [optional] 
**endTime** | **Date** |  | [optional] 
**status** | **String** |  | 
**message** | **String** |  | [optional] 
**linkURL** | **String** |  | [optional] 
**linkText** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


