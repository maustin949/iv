# infoplus.ApplyOrderWarehouseFulfillmentPlanInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderNo** | **String** |  | 
**plan** | [**OrderWarehouseFulfillmentPlan**](OrderWarehouseFulfillmentPlan.md) |  | 


