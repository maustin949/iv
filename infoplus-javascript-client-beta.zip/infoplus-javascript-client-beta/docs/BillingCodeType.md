# infoplus.BillingCodeType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**clientId** | **Number** |  | 
**billingCode** | **String** |  | 
**name** | **String** |  | 
**description** | **String** |  | [optional] 
**isActive** | **Boolean** |  | [optional] [default to false]
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


