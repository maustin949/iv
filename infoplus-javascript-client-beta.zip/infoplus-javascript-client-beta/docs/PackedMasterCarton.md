# infoplus.PackedMasterCarton

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


