# infoplus.WorkProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lobId** | **Number** |  | [optional] 
**sku** | **String** |  | [optional] 
**itemDescription** | **String** |  | [optional] 
**poNo** | **String** |  | [optional] 
**quantity** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


