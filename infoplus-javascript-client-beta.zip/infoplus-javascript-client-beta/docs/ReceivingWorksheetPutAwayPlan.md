# infoplus.ReceivingWorksheetPutAwayPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


