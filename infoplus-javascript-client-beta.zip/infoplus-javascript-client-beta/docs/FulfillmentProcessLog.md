# infoplus.FulfillmentProcessLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**processId** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | [optional] 
**orderNo** | **Number** |  | [optional] 
**lobId** | **Number** |  | [optional] 
**sku** | **String** |  | [optional] 
**locationId** | **Number** |  | [optional] 
**itemReceiptId** | **Number** |  | [optional] 
**allocationIssueType** | **String** |  | [optional] 
**message** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


