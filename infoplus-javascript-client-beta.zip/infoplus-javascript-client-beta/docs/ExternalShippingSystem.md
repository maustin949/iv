# infoplus.ExternalShippingSystem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | 
**systemType** | **String** |  | 
**scriptId** | **Number** |  | [optional] 
**explodeAllKitContents** | **Boolean** |  | [default to false]
**apiKey** | **String** |  | 
**apiSecret** | **String** |  | 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


