# infoplus.ReqManualSubstitutionInputAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderNoList** | **[Number]** |  | [optional] 
**originalSKU** | **String** |  | [optional] 
**originalKitSKU** | **String** |  | [optional] 
**originalQuantity** | **Number** |  | [optional] 
**originalComponentSKU** | **String** |  | [optional] 
**newSKU** | **String** |  | [optional] 
**newQuantity** | **Number** |  | [optional] 
**editType** | **String** |  | 


