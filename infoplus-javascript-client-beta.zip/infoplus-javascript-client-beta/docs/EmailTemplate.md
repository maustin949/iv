# infoplus.EmailTemplate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**lobId** | **Number** |  | 
**subject** | **String** |  | 
**name** | **String** |  | 
**fromName** | **String** |  | 
**fromAddress** | **String** |  | 
**toName** | **String** |  | [optional] 
**toAddress** | **String** |  | [optional] 
**ccAddress** | **String** |  | [optional] 
**bccAddress** | **String** |  | [optional] 
**emailTemplateType** | **String** |  | 
**recordType** | **String** |  | [optional] 
**apiVersion** | **String** |  | [optional] 
**scriptId** | **Number** |  | [optional] 
**sendToBillTo** | **Boolean** |  | [optional] [default to false]
**sendToShipTo** | **Boolean** |  | [optional] [default to false]
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


