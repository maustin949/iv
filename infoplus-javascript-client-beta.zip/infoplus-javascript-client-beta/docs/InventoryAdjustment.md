# infoplus.InventoryAdjustment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**lobId** | **Number** |  | [optional] 
**sku** | **String** |  | [optional] 
**poNoId** | **Number** |  | [optional] 
**adjustmentDate** | **Date** |  | [optional] 
**adjustmentTime** | **String** |  | [optional] 
**location** | **String** |  | [optional] 
**qty** | **Number** |  | [optional] 
**note** | **String** |  | [optional] 
**authorizedBy** | **String** |  | [optional] 
**printed** | **String** |  | [optional] 
**orderNo** | **Number** |  | [optional] 
**adjustmentCode** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


