# infoplus.StandardBusinessDays

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**sunday** | **Boolean** |  | [optional] [default to false]
**monday** | **Boolean** |  | [optional] [default to false]
**tuesday** | **Boolean** |  | [optional] [default to false]
**wednesday** | **Boolean** |  | [optional] [default to false]
**thursday** | **Boolean** |  | [optional] [default to false]
**friday** | **Boolean** |  | [optional] [default to false]
**saturday** | **Boolean** |  | [optional] [default to false]
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


