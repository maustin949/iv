# infoplus.LoggedTime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**start** | **Date** |  | [optional] 
**end** | **Date** |  | [optional] 
**duration** | **Number** |  | 
**description** | **String** |  | [optional] 
**client** | **Number** |  | 
**userId** | **Number** |  | 
**lobId** | **Number** |  | [optional] 
**warehouseId** | **Number** |  | 
**loggedTimeTypeId** | **Number** |  | 
**appId** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


