# infoplus.BillOfLadingOrderInfoLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerOrderNo** | **String** |  | [optional] 
**noPackages** | **Number** |  | [optional] 
**weight** | **Number** |  | [optional] 
**palletslip** | **Boolean** |  | [optional] [default to false]
**additionalShipperInfo** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


