# infoplus.PackingDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**lobId** | **Number** |  | [optional] 
**orderId** | **Number** |  | [optional] 
**palletId** | **Number** |  | [optional] 
**masterCartonId** | **Number** |  | [optional] 
**cartonId** | **Number** |  | [optional] 
**sku** | **String** |  | [optional] 
**itemReceiptId** | **Number** |  | [optional] 
**lineItemId** | **Number** |  | [optional] 
**quantity** | **Number** |  | [optional] 
**cartonGS1128Label** | [**[GS1128LabelDTO]**](GS1128LabelDTO.md) |  | [optional] 
**palletGS1128Label** | [**[GS1128LabelDTO]**](GS1128LabelDTO.md) |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


