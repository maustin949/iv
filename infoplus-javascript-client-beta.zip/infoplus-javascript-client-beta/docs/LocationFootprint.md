# infoplus.LocationFootprint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**clientId** | **Number** |  | 
**name** | **String** |  | 
**width** | **Number** |  | [optional] 
**depth** | **Number** |  | [optional] 
**height** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


