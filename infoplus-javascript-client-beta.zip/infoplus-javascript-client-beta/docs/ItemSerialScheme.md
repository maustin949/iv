# infoplus.ItemSerialScheme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**name** | **String** |  | [optional] 
**receivingBehavior** | **String** |  | 
**shippingBehavior** | **String** |  | 
**requireUnique** | **String** |  | 
**allowUniqueSerialReturns** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


