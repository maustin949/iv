# infoplus.Store

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storeName** | **String** |  | 
**storeId** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


