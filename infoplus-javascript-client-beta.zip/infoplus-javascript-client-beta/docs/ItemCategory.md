# infoplus.ItemCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lobId** | **Number** |  | 
**internalId** | **Number** |  | [optional] 
**id** | **String** |  | 
**name** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


