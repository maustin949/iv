# infoplus.Supplement

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lobId** | **Number** |  | 
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**originalSKUId** | **Number** |  | 
**supplementSKUId** | **Number** |  | 
**type** | **String** |  | 
**supplementQuantity** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 


