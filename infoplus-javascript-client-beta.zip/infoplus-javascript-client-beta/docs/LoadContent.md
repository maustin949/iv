# infoplus.LoadContent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**loadId** | **Number** |  | 
**masterCartonId** | **Number** |  | [optional] 
**lobId** | **Number** |  | [optional] 
**cartonId** | **Number** |  | [optional] 
**itemId** | **Number** |  | [optional] 
**itemReceiptId** | **Number** |  | [optional] 
**quantity** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


