# infoplus.CartLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**cartId** | **Number** |  | 
**address** | **String** |  | 
**customFields** | **{String: Object}** |  | [optional] 


