# infoplus.OrderSourceStockStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**orderSourceId** | **Number** |  | 
**lobId** | **Number** |  | [optional] 
**totalReservedQuantity** | **Number** |  | [optional] 
**demand** | **Number** |  | [optional] 
**reservedQuantity** | **Number** |  | [optional] 
**quantityAvailable** | **Number** |  | [optional] 
**orderableQuantity** | **Number** |  | [optional] 
**unreservedQuantityAvailable** | **Number** |  | [optional] 
**netReservation** | **Number** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 
**sku** | **String** |  | [optional] 


