# infoplus.ProductionLot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**lobId** | **Number** |  | [optional] 
**productionLot** | **String** |  | 
**quantity** | **Number** |  | 
**customFields** | **{String: Object}** |  | [optional] 
**sku** | **String** |  | [optional] 


