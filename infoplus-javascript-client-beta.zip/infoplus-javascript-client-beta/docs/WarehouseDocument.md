# infoplus.WarehouseDocument

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**documentType** | **String** |  | 
**printerType** | **String** |  | 
**clientId** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**createDate** | **Date** |  | [optional] 
**modifyDate** | **Date** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


