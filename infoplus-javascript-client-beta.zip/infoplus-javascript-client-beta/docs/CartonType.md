# infoplus.CartonType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**abbreviation** | **String** |  | 
**name** | **String** |  | 
**lengthIn** | **Number** |  | 
**widthIn** | **Number** |  | 
**heightIn** | **Number** |  | 
**innerLengthIn** | **Number** |  | 
**innerWidthIn** | **Number** |  | 
**innerHeightIn** | **Number** |  | 
**weightLbs** | **Number** |  | [optional] 
**lobId** | **Number** |  | 
**isActive** | **Boolean** |  | [default to false]
**predefinedPackageTypeId** | **Number** |  | [optional] 
**origin** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**customFields** | **{String: Object}** |  | [optional] 


